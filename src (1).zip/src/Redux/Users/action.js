
export const USER_DETAILS = "USER_DETAILS";

export const user_details = (payload) =>({type:USER_DETAILS,payload})