import React from 'react';
import './App.css';
import { AllRoutes } from "./Components/Routes"

function App() {
   return <div className="App">
        <AllRoutes />
    </div>
}

export default App;

// import { Homepage } from './components/Homepage/Homepage';
// import { Login } from './components/Login/Login';
// import { Register } from './components/Register/Register';
// import { Step2 } from "./components/Login/Step2"

// import { Step3 } from "./components/Login/Step3"